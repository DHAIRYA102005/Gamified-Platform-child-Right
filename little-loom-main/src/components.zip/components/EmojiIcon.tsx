/**
 * EmojiIcon Component
 * 
 * Replaces emojis with Lucide React icons or custom images
 * Falls back to emoji if icon/image not found
 */

import {
  Gamepad2,
  Trophy,
  Shield,
  BookOpen,
  Star,
  Sparkles,
  Target,
  Award,
  Zap,
  Heart,
  Users,
  Brain,
  Search,
  Building2,
  Play,
  Lock,
  CheckCircle2,
  Phone,
  ArrowRight,
  ChevronRight,
  Sparkle,
  Gift,
  Gem,
  Medal,
} from 'lucide-react';
import { motion } from 'framer-motion';

// Inline SVG for superhero - using the custom SVG from src/a.svg
const SuperheroSVGContent = ({ size, className, color }: { size?: number | string; className?: string; color?: string }) => {
  const sizeValue = typeof size === 'number' ? size : parseInt(size as string) || 24;
  const fillColor = color || 'currentColor';
  
  return (
    <svg 
      fill={fillColor} 
      height={sizeValue} 
      width={sizeValue} 
      version="1.1" 
      xmlns="http://www.w3.org/2000/svg" 
      xmlnsXlink="http://www.w3.org/1999/xlink" 
      viewBox="0 0 203 256" 
      className={className}
      style={{ display: 'inline-block' }}
    >
      <defs>
        <style>{`.st0{fill:none;}`}</style>
      </defs>
      <g>
        <path className="st0" d="M101.7,152.3c-1.4,0-2.3,1-2.3,2.3v61.1h4.6v-61.1C104,153.2,103,152.3,101.7,152.3z"/>
        <path className="st0" d="M152.5,104.9v39.4c0,4.9-4.1,8.9-8.9,8.9c-4.9,0-8.9-4.1-8.9-8.9v-43.6l-8-11.7v35.9h-16.1
          c-1.5-3.2-4.8-5.5-8.6-5.5c-3.8,0-7.1,2.2-8.6,5.5H76.8l-0.1-35.9l-8,11.7v43.6c0,4.9-4,8.9-8.9,8.9c-4.9,0-8.9-4.1-8.9-8.9v-39.4
          C21.3,142.3,8,174.4,5.2,216c2.8-2.4,7.7-4.4,15.3-4c9.6,0.4,15.3,4.4,20.1,8c6.4,4.8,10.4,7.6,20.5,1.2c4.8-2.8,9.7-4.8,14.1-5.6
          h1.4l-0.1-83.2v0.1h-3.3V125h3.3v7.4H93c1.4,3.5,4.8,6,8.9,6c4.1,0,7.5-2.5,8.9-6h15.8V125h3.4v7.5h-3.4v83.4
          c4.1,0.9,8.5,2.5,12.9,5.4c10.4,6.4,14.5,3.2,20.5-1.2c4.8-3.2,10.4-7.6,20.1-8c7.6-0.4,12.5,1.7,16.2,3.9
          C195.3,174.8,182,142.3,152.5,104.9z" fill="none"/>
        <path d="M151.6,97.2v-3.6l-16.9-25c-5.2-7.2-11.3-10.5-19.7-10.5H87.5c-8.5,0-14.5,3.6-19.7,10.5l-16.9,25v3.6
          c-34.3,42.3-50,78.6-50,125.7l6,0.4c0-0.4,1.6-8,14.9-7.2c8.5,0.4,13.3,4,17.7,7.2c4,2.8,7.6,5.6,12.9,5.6c3.2,0,7.2-1.2,12.5-4.4
          c4-2.4,8-4,11.7-5.2h0.2v18.5c0,6.3,5,11.3,11.3,11.3s11.3-5,11.3-11.3v-18.5h4.6v18.5c0,6.3,5,11.3,11.3,11.3s11.3-5,11.3-11.3
          v-18.3c3.4,0.9,7.1,2.4,10.9,5c4.8,3.2,8.9,4.4,12.5,4.4c5.2,0,8.9-2.8,12.9-5.6c4.4-3.2,9.7-6.8,17.7-7.2
          c13.3-0.8,14.9,6.8,14.9,7.2l6-0.4C201.5,175.8,185.5,139.5,151.6,97.2z M104,215.8h-4.6v-61.1c0-1.3,0.9-2.3,2.3-2.3
          c1.3,0,2.3,0.9,2.3,2.3V215.8z M180.3,212.1c-9.7,0.4-15.3,4.8-20.1,8c-6,4.4-10.1,7.6-20.5,1.2c-4.4-2.9-8.8-4.5-12.9-5.4v-83.4
          h3.4V125h-3.4v7.4h-15.8c-1.4,3.5-4.8,6-8.9,6c-4.1,0-7.5-2.5-8.9-6H76.7l0.1,83.2h-1.4c-4.4,0.8-9.3,2.8-14.1,5.6
          c-10.1,6.4-14.1,3.6-20.5-1.2c-4.8-3.6-10.5-7.6-20.1-8c-7.6-0.4-12.5,1.6-15.3,4c2.8-41.6,16.1-73.6,45.6-111.1v39.4
          c0,4.8,4,8.9,8.9,8.9c4.9,0,8.9-4,8.9-8.9v-43.6l8-11.7l0.1,35.9h16.5c1.5-3.3,4.8-5.5,8.6-5.5c3.8,0,7.1,2.3,8.6,5.5h16.1V88.9
          l8,11.7v43.6c0,4.8,4,8.9,8.9,8.9c4.8,0,8.9-4,8.9-8.9v-39.4c29.5,37.5,42.8,69.9,44,111.1C192.8,213.8,187.9,211.7,180.3,212.1z"
        />
        <polygon points="73.3,125 73.3,132.5 76.7,132.5 76.7,132.4 76.7,125"/>
        <circle cx="101.5" cy="29.4" r="20.7"/>
      </g>
    </svg>
  );
};

interface EmojiIconProps {
  emoji: string;
  size?: number | string;
  className?: string;
  animated?: boolean;
  color?: string;
  textSize?: 'xs' | 'sm' | 'base' | 'lg' | 'xl' | '2xl' | '3xl' | '4xl' | '5xl' | '6xl' | '7xl' | '8xl' | '9xl';
}

// Custom SVG component for superhero - using inline SVG from src/a.svg
const SuperheroIcon = SuperheroSVGContent;

// Map emojis to Lucide React icons or custom components
const emojiToIconMap: Record<string, React.ComponentType<{ size?: number | string; className?: string; color?: string }>> = {
  // Gaming
  '🎮': Gamepad2,
  '🎯': Target,
  '🏆': Trophy,
  '🎨': Sparkles,
  '🎲': Gamepad2, // No dice icon, using gamepad
  
  // Education
  '📚': BookOpen,
  '📖': BookOpen,
  
  // Safety
  '🛡️': Shield,
  
  // Achievements
  '⭐': Star,
  '🌟': Star,
  '✨': Sparkle,
  '🏅': Medal,
  '⚡': Zap,
  '🔥': Zap, // Using zap for fire
  '💎': Gem,
  '🎁': Gift,
  
  // People
  '👥': Users,
  '🦸': SuperheroIcon, // Custom SVG
  
  // Actions
  '💪': Zap,
  '💖': Heart,
  '🚀': ArrowRight,
  
  // Games
  '🧠': Brain,
  '🔍': Search,
  '🏙️': Building2,
  '🏃': Play,
  
  // Status
  '✅': CheckCircle2,
  '🔒': Lock,
  '📞': Phone,
};

// Map text sizes to pixel sizes for icons
const textSizeToPixels: Record<string, number> = {
  xs: 12,
  sm: 14,
  base: 16,
  lg: 18,
  xl: 20,
  '2xl': 24,
  '3xl': 30,
  '4xl': 36,
  '5xl': 48,
  '6xl': 60,
  '7xl': 72,
  '8xl': 96,
  '9xl': 128,
};

export function EmojiIcon({ 
  emoji, 
  size, 
  className = '',
  animated = false,
  color,
  textSize
}: EmojiIconProps) {
  const Icon = emojiToIconMap[emoji];
  
  // Determine actual size
  let actualSize: number | string = size || 24;
  if (textSize) {
    actualSize = textSizeToPixels[textSize] || 24;
  }
  
  if (Icon) {
    const iconElement = (
      <Icon 
        size={actualSize} 
        className={className}
        color={color}
      />
    );
    
    if (animated) {
      return (
        <motion.div
          animate={{
            y: [0, -10, 0],
            rotate: [0, 5, -5, 0],
            scale: [1, 1.1, 1],
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
          className="inline-flex items-center justify-center"
        >
          {iconElement}
        </motion.div>
      );
    }
    
    return <span className="inline-flex items-center justify-center">{iconElement}</span>;
  }
  
  // Fallback to emoji
  const sizeClass = textSize ? `text-${textSize}` : (typeof size === 'number' 
    ? `text-[${size}px]` 
    : size || 'text-base');
    
  return (
    <span className={`${sizeClass} ${className}`}>
      {emoji}
    </span>
  );
}

/**
 * Usage Examples:
 * 
 * // Simple replacement
 * <EmojiIcon emoji="🎮" size={32} />
 * 
 * // With animation
 * <EmojiIcon emoji="⭐" size={48} animated />
 * 
 * // With custom styling
 * <EmojiIcon emoji="🏆" size={64} className="text-yellow-500" />
 * 
 * // Falls back to emoji if icon not found
 * <EmojiIcon emoji="🎉" size={32} />
 */
